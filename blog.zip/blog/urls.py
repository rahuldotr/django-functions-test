from  django.urls import path
from . import views
from django.contrib.auth import views as auth_views
from django.conf.urls import include, url


urlpatterns = [
path('insert-data/', views.insert_blog, name='insert_blog'),
path('show-blog/<int:requested_blog_id>/', views.showBlogDetails, name='requested_blog_id'),
path('insert-data/show-blog', views.showBlog, name='requested_blog_id'),
path('show-blog/', views.showBlog, name='requested_blog_id'),
path('show-blog/insert-data', views.insert_blog, name='insert_blog'),
path('show-blog/edit-form/<int:requested_blog_id>', views.edit_blog, name='edit-form'),
# path('edit-form/<int:requested_blog_id>/', views.edit_blog, name='edit-form'),
path('show-blog/delete-form/<int:requested_blog_id>/', views.delete_blog, name='delete-form'),
path('show-blog/', views.showBlog, name='requested_blog_id'),
path('show-blogs/', views.listBlogs, name='requested_blog_id'),
path('', views.blog, name='blog'),
path('signup/', views.signup, name='blog'),
path('login/', views.login_123, name='blog'),
path('login/logout/', views.logout_view, name='blog'),
path('image/', views.upload_file, name='blog'),
path('showimage/', views.showImage, name='blog'),

path('mail/', views.sendMailToUser, name='blog'),
path('ajax/', views.sample_view, name='blog'),


path('apilogin/', views.apilogin, name='blog'),









]