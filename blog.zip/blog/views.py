from django.shortcuts import render
from django.http import HttpResponse
from django.core.paginator import Paginator
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login
from django.contrib.auth import logout
from django.http import  HttpResponseRedirect     
from django.shortcuts import redirect
from django.contrib import messages
from django.shortcuts import get_object_or_404, render
from .models import Images
from django.core.mail import EmailMessage
from django.http import JsonResponse
from django.contrib.auth import authenticate
from django.views.decorators.csrf import csrf_exempt
from rest_framework.authtoken.models import Token
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import AllowAny
from rest_framework.status import (
    HTTP_400_BAD_REQUEST,
    HTTP_404_NOT_FOUND,
    HTTP_200_OK
)
from rest_framework.response import Response
from rest_framework.authtoken.views import obtain_auth_token






# Create your views here.

from blog.models import Blog
from .forms import BlogForm
from blog.models import Entry
from .forms import form
from .forms import SignupForm
from .forms import LoginForm
from .forms import UploadFileForm


def insert_blog(request):
    if request.method == 'POST':

        blog_form = BlogForm(request.POST)
        if blog_form.is_valid():

            blog_name_from_user = blog_form.cleaned_data['blog_name'] 
            blog_tagline_from_user = blog_form.cleaned_data['blog_tag_line'] 

            blog_object = Blog(name=blog_name_from_user, tagline=blog_tagline_from_user)
            blog_object.save() # will save the data from the form to database

            entry_object = Entry()
            entry_object.headline = "Lorum Ipsum"
            entry_object.body_text = """Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."""
            entry_object.pub_date = "2018-07-04"
            entry_object.mod_date = "2018-07-04"
            entry_object.n_comments = 0
            entry_object.n_pingbacks = 0
            entry_object.rating = 5
            entry_object.blog = blog_object # will insert the blog id into blog_entry
            entry_object.save()
            return HttpResponse('Data Inserted successfully')

    else:
        blog_form = BlogForm()
        return render(request, 'blog/insert-form.html', {'form': blog_form}) 

def showBlogDetails(request,requested_blog_id):
	blog_details = Entry.objects.prefetch_related("blog").get(blog_id=requested_blog_id)
	context = {"blog_details":blog_details}
	return render(request,"blog/view-blog.html",context)	


def blog(request):
        return render(request,"blog/blog.html")






def edit_blog(request,requested_blog_id):
    if request.method == 'POST':

        blog_form = BlogForm(request.POST)
        if blog_form.is_valid():

                blog_details = Blog.objects.get(id=requested_blog_id) # this will select datafrom database 
                blog_details.name = blog_form.cleaned_data['blog_name']
                blog_details.tagline = blog_form.cleaned_data['blog_tag_line']
                blog_details.save()
                return HttpResponse('Data Edited successfully')
    else:


        blog_details = Blog.objects.get(id=requested_blog_id) # this will select datafrom database 
        blog_form = BlogForm(initial={"blog_name":blog_details.name,"blog_tag_line":blog_details.tagline}) # this will set initial values in the form from selected data

    return render(request, 'blog/edit-blog.html', {'form': blog_form,'blog_id':requested_blog_id,})


def delete_blog(request,requested_blog_id):
        blog_details = Blog.objects.get(id=requested_blog_id)  
        blog_details.delete()
        return HttpResponse('Data Deleted successfully')

def showBlog(request):
        blog_details = Blog.objects.all()
        paginator = Paginator(blog_details, 2)
        page = request.GET.get('page')
        blogs = paginator.get_page(page)
        context = {"blog_details":blog_details}
        return render(request,"blog/view-blogdetail.html",context,{"blogs":blogs})



def listBlogs(request):

    blogs_list = Blog.objects.all()
    paginator = Paginator(blogs_list, 2)
    page = request.GET.get('page')
    blogs = paginator.get_page(page)

    return render(request, "blog/view-blogdetail.html",{"blogs":blogs})


def signup(request):
	if request.method == 'POST':
			signup_form = SignupForm(request.POST)
			if signup_form.is_valid():
				username = signup_form.cleaned_data['username']	
				email = signup_form.cleaned_data['email']	
				password = signup_form.cleaned_data['password']	
				if  User.objects.filter(username=username).exists():
                                        messages.success(request, 'The Account does not exists')  # <-
				else:	
				
					user = User.objects.create_user(username, email, password)
					user.save()
					return HttpResponse("Signup successfull")
	else:
		signup_form = SignupForm(request.POST)
	return render(request, 'blog/signup.html',{"form":signup_form})
        
def login_123(request):
        if request.user.is_authenticated:
                return render(request,"blog/dashboard.html")
        else:	
                if request.method == 'POST':
                        login_form = LoginForm(request.POST)
                        if login_form.is_valid():

                                username = login_form.cleaned_data['username']
                                password = login_form.cleaned_data['password']

                                user = authenticate(username=username, password=password)
                                                                
                                if user is not None:
                                        if user.is_active:
                                                login(request, user)	
                                                return render(request,"blog/dashboard.html")
                                        else:
                                                messages.success(request, 'The Account not active..!!')  # <-
                                else:
                                        # return HttpResponse('The Account does not exists')
                                        messages.success(request, 'The Account does not exists')  # <-

                        else:
                                login_form = LoginForm()
                                return render(request, "blog/login.html",{"form":login_form})
                else:
                        login_form = LoginForm()
                return render(request, "blog/login.html",{"form":login_form})
					
def logout_view(request):
    logout(request)
    return render(request,"blog/logout.html")




def upload_file(request):
    if request.method == 'POST':
        form = UploadFileForm(request.POST, request.FILES)
        if form.is_valid():
            instance = Images(image=request.FILES['image'])
            instance.save()
            messages.add_message(request, messages.SUCCESS, 'Successfully added')
            return HttpResponseRedirect('/blog/image')

    else:
        form = UploadFileForm()
    return render(request, 'blog/upload.html', {'form_f': form})


    
def showImage(request):
    img = Images.objects.all()
    context = {"image":img}
    return render(request,"blog/image_preview.html",context,{"image":img})



#     return render(request, 'blog/image_preview.html', {"file":img})

    


def sendMailToUser():
	subject = "Subject here"			
	message = "Here is the Message"
	sender = "rahuldotrnair@gmail.com"
	recievers = ["rahuldotrnair@gmail.com"]
	msg = EmailMessage(subject,message,sender,recievers)
	msg.content_subtype = "html"
	msg.send()
	

def sample_view(request):
        blog_details = Blog.objects.all()
        context = {"blog_details":blog_details}
        return render(request,"blog/ajax.html",context,{"blogs":blogs})






@csrf_exempt
@api_view(["POST"])
@permission_classes((AllowAny,))
def apilogin(request):
    username = request.data.get("username")
    password = request.data.get("password")
    if username is None or password is None:
        return Response({'error': 'Please provide both username and password'},
                        status=HTTP_400_BAD_REQUEST)
    user = authenticate(username=username, password=password)
    if not user:
        return Response({'error': 'Invalid Credentials'},
                        status=HTTP_404_NOT_FOUND)
    token, _ = Token.objects.get_or_create(user=user)
    return Response({'token': token.key},
                    status=HTTP_200_OK)

    
				
        


    